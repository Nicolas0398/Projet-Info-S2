var namespacegrman =
[
    [ "ArrowItem", "structgrman_1_1_arrow_item.html", "structgrman_1_1_arrow_item" ],
    [ "Widget", "classgrman_1_1_widget.html", "classgrman_1_1_widget" ],
    [ "WidgetBox", "classgrman_1_1_widget_box.html", "classgrman_1_1_widget_box" ],
    [ "WidgetButton", "classgrman_1_1_widget_button.html", "classgrman_1_1_widget_button" ],
    [ "WidgetCheckBox", "classgrman_1_1_widget_check_box.html", "classgrman_1_1_widget_check_box" ],
    [ "WidgetEdge", "classgrman_1_1_widget_edge.html", "classgrman_1_1_widget_edge" ],
    [ "WidgetImage", "classgrman_1_1_widget_image.html", "classgrman_1_1_widget_image" ],
    [ "WidgetText", "classgrman_1_1_widget_text.html", "classgrman_1_1_widget_text" ],
    [ "WidgetVSlider", "classgrman_1_1_widget_v_slider.html", "classgrman_1_1_widget_v_slider" ]
];