var class_graph_interface =
[
    [ "GraphInterface", "class_graph_interface.html#afdc8c063edd6775ad16e5dc1b0597e9a", null ],
    [ "Graph", "class_graph_interface.html#afab89afd724f1b07b1aaad6bdc61c47a", null ]
];