var struct_frame =
[
    [ "Frame", "struct_frame.html#ad2e5946cf41d4817e750500acf05d02b", null ],
    [ "Frame", "struct_frame.html#a25abfa03084fb3433d8a31b5ce4b3e03", null ],
    [ "Frame", "struct_frame.html#a69bd3486fc68c03e42b7692ee62c36a7", null ],
    [ "intersect", "struct_frame.html#aa53a6d89610817455b7eca80202482e7", null ],
    [ "dim", "struct_frame.html#a5f8b607848440beb3fda8bc7ae26f13e", null ],
    [ "pos", "struct_frame.html#ab1623c15654af546fd697b30b1ee7f41", null ]
];