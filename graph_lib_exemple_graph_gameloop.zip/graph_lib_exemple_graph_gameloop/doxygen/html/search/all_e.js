var searchData=
[
  ['update',['update',['../classgrman_1_1_widget.html#a22b2a25ad397e05dfd21fd834d667ec5',1,'grman::Widget::update()'],['../class_graph.html#a97b4fe3e0f119971649ed33e3c364cde',1,'Graph::update()']]],
  ['update_5fdraw',['update_draw',['../classgrman_1_1_widget.html#a581df4bb0e082d674253f142667a5d81',1,'grman::Widget']]],
  ['update_5finteract',['update_interact',['../classgrman_1_1_widget.html#ab214adec555487fd72702eb735d445cc',1,'grman::Widget']]],
  ['update_5fpre_5fdraw',['update_pre_draw',['../classgrman_1_1_widget.html#afaee30b61971b479976f96eb8a9f7628',1,'grman::Widget']]]
];
