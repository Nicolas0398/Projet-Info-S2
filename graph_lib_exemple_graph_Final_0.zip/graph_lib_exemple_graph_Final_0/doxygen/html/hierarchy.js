var hierarchy =
[
    [ "grman::ArrowItem", "structgrman_1_1_arrow_item.html", null ],
    [ "Coords", "struct_coords.html", null ],
    [ "Edge", "class_edge.html", null ],
    [ "EdgeInterface", "class_edge_interface.html", null ],
    [ "Frame", "struct_frame.html", null ],
    [ "Graph", "class_graph.html", null ],
    [ "GraphInterface", "class_graph_interface.html", null ],
    [ "Vertex", "class_vertex.html", null ],
    [ "VertexInterface", "class_vertex_interface.html", null ],
    [ "grman::Widget", "classgrman_1_1_widget.html", [
      [ "grman::WidgetBox", "classgrman_1_1_widget_box.html", null ],
      [ "grman::WidgetButton", "classgrman_1_1_widget_button.html", null ],
      [ "grman::WidgetCheckBox", "classgrman_1_1_widget_check_box.html", null ],
      [ "grman::WidgetEdge", "classgrman_1_1_widget_edge.html", null ],
      [ "grman::WidgetImage", "classgrman_1_1_widget_image.html", null ],
      [ "grman::WidgetText", "classgrman_1_1_widget_text.html", null ],
      [ "grman::WidgetVSlider", "classgrman_1_1_widget_v_slider.html", null ]
    ] ]
];