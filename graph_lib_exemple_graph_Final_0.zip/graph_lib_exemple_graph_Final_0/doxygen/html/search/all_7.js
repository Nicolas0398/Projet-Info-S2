var searchData=
[
  ['init',['init',['../namespacegrman.html#ab4c5898d4a76764b9ef2ef86165588de',1,'grman']]]
];
