var searchData=
[
  ['page_5fcolor',['page_color',['../namespacegrman.html#a1576bfdaffb0e7a44eec352a321e1103',1,'grman']]]
];
