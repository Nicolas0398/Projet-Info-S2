var classgrman_1_1_widget_image =
[
    [ "WidgetImage", "classgrman_1_1_widget_image.html#af9a67025da24eeea3d3ebcea0f492ed1", null ],
    [ "draw", "classgrman_1_1_widget_image.html#a06e44ca3302524a1ec5c7eacf16ca2b3", null ],
    [ "reframe", "classgrman_1_1_widget_image.html#af164b59bc1533a8215f438c84f891c2a", null ],
    [ "set_animate", "classgrman_1_1_widget_image.html#a0ef99f5a07b9d4d7c843b6c57a409bf8", null ],
    [ "set_animate_tempo", "classgrman_1_1_widget_image.html#ac095ed76d988ba8cc15a1cb5a43be408", null ],
    [ "set_pic_idx", "classgrman_1_1_widget_image.html#abaf937bd9edc6e51d4286021d1e302ff", null ],
    [ "set_pic_name", "classgrman_1_1_widget_image.html#a024e6d7101993d1dbc022f02241e3484", null ],
    [ "m_animate", "classgrman_1_1_widget_image.html#a3f9de67569947007110680dcb17b97eb", null ],
    [ "m_animate_cpt_tempo", "classgrman_1_1_widget_image.html#af92a7de5a4447417bc7ce4e12947acb8", null ],
    [ "m_animate_tempo", "classgrman_1_1_widget_image.html#a9d24ac9f396873fc0c0a6cf0680e8d54", null ],
    [ "m_pic_idx", "classgrman_1_1_widget_image.html#ad5bf61889812d0eee9be1fac140a1764", null ],
    [ "m_pic_name", "classgrman_1_1_widget_image.html#ab8c9481e7cc708006598812bf25ce233", null ]
];