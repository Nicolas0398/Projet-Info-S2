var structgrman_1_1_arrow_item =
[
    [ "ArrowItem", "structgrman_1_1_arrow_item.html#ac8e314540ee54b43d5bb0d5a1f178d01", null ],
    [ "m_position", "structgrman_1_1_arrow_item.html#a2592668e21b5d0e62eee3977b3337fda", null ],
    [ "m_proportion", "structgrman_1_1_arrow_item.html#ac26bdc3069d42bff6f18d5dfa50fadde", null ],
    [ "m_size", "structgrman_1_1_arrow_item.html#a27e619cd38e8210bbe39016aa5d9dc18", null ],
    [ "m_type", "structgrman_1_1_arrow_item.html#af0cbe30f898453a2b6507f812753190e", null ]
];